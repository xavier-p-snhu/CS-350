/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Use the timer driver */
#include <ti/drivers/Timer.h>


//Morse code arrays
//'r' is red, 'g' is green, 'o' is off
char sos[34] = {
                /*start S*/ 'r', 'o', 'r', 'o', 'r', /*end S*/ 'o', 'o', 'o',
                /*start O*/ 'g', 'g', 'g', 'o', 'g', 'g', 'g', 'o', 'g', 'g', 'g', /*end O*/ 'o', 'o', 'o',
                /*start S*/ 'r', 'o', 'r', 'o', 'r', /*end S*/
                /*start word space*/ 'o', 'o', 'o', 'o', 'o', 'o', 'o' /*end*/

};
char ok[31] = {
             /*start O*/ 'g', 'g', 'g', 'o', 'g', 'g', 'g', 'o', 'g', 'g', 'g', /*end O*/ 'o', 'o', 'o',
             /*start K*/ 'g', 'g', 'g', 'o', 'r', 'o', 'g', 'g', 'g', 'o', /*end k*/
             /*start word space*/ 'o', 'o', 'o', 'o', 'o', 'o', 'o' /*end*/
};

//State machine variables
bool sosPatternCurrent = true; // true if pattern is 'sos', false if pattern is 'ok'
bool sosPatternNext = true; // used for the interrupt
int morseProgress = 0; // index in the morse code array
int arraySize = 0; // size of the morse code array

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    sosPatternNext = !sosPatternNext; // invert the pattern between 'sos' and 'ok' for the next interrupt
}

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    // get the current LED state ('r', 'g', or 'o') for the next Morse code signal
    char currentLed; //current LED to turn on. 'r' for red, 'g' for green, 'o' for off (none)
    if (sosPatternCurrent) {
        // get size of the 'sos' array
        arraySize = sizeof(sos) / sizeof(sos[0]);
        currentLed = sos[morseProgress]; //get LED from 'sos' pattern array
    }
    else {
        // get size of the 'ok' array
        arraySize = sizeof(ok) / sizeof(ok[0]);
        currentLed = ok[morseProgress]; //get LED from 'ok' pattern array
    }

    // turn on/off LEDs based on the current Morse code character ('r', 'g', or 'o')
    switch(currentLed)
    {
    case 'o':
        //turn off both LEDs
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
        break;
    case 'r':
        //turn on just red LED
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
        break;
    case 'g':
        //turn on just green LED
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
        break;
    }

    //increment array
    morseProgress++;

    //if morseProgress is greater than length of array, reset
    if (morseProgress >= arraySize) {
        morseProgress = 0; //start at beginning of array
        sosPatternCurrent = sosPatternNext; //change to the next pattern if needed
    }
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialize timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /* Initialize Timer */
    initTimer();

    return (NULL);
}


